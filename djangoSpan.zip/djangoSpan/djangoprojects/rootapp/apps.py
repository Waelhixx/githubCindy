from django.apps import AppConfig


class RootappConfig(AppConfig):
    name = 'rootapp'
