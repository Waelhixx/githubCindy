 div><html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>FINAL PROJECT</title>
    </head>
    <body>
        <p>
        <p> Eduardo JR. J. Cenabre</p> <BR>
          
        <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:15cm">
            <h1>Narrative Report in Hadoop    
            </h1>
        </div>
            <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:1m">
    
         </div>
             </div>

        <html>
        <head>
           
        </body>
        </html>
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
        
            <title>laravel</title>
        
        
            <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        
            <style>
                body {
                    font-family: 'Nunito', sans-serif;
                }
            </style>
        </head>
        <body>
           <html lang="en">
           <head>
            </head>
           <body>
            <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm", style="margin-left:1m"> 
            <p> Hadoop is an open-source framework that stores and process big data in a distributed environment using simple programming models.
                It is designed to scale up from single servers to thousands of machines, 
                 while each offers <br>
                 local computation and storage. 
                Hadoop divides a file into blocks and stores across a cluster of machines. It achieves fault tolerance by replicating the blocks on a cluster. 
                Hadoop can be used as a flexible and easy way <br>
                 for the distributed processing of large enterprise data sets. 
                Apart from humongous data, it includes structured, semi-structured, and unstructured data including Internet clickstreams records, <br>
                web server, social media posts, customer emails, mobile application logs, and sensor data from the Internet of Things (IoT).
                In sort, Big data is made simple with Hadoop. 
                So, Hadoop professionals get hired everywhere. <br>
                It is an in-demand job nowadays. <br>
        <p></p>  
           
    <p></p>